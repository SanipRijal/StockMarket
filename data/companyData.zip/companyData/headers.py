import csv
with open('API/agm.csv','r') as f:
    r = csv.reader(f)
    data = [line for line in r]
with open('API/agm.csv','w') as f:
    w = csv.writer(f)
    w.writerow(['Fiscal Year', 'Dividend', 'Bonus', 'Right Share'])
    w.writerows(data)